//
//  Airline.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Airline{
    var AirlineID : String?
   
    private var category : AirlineCategory?
    
    
    private var AirlineDescription : String?{
        
        get{
            
            return self.AirlineDescription
            
        }
        
        set{
            
            self.AirlineDescription = newValue
            
        }
        
    }
    
    
    
    private var AirlineType : String?{
        
        get{
            
            return self.AirlineType
            
        }
        
        set{
            
            self.AirlineType = newValue
            
        }
        
    }
    var Category : AirlineCategory?{
        
        get{
            
            return self.category
            
        }
        set{
            
            self.category = newValue
            
        }
    }
    
    
    
    
    
    init(){
        
        self.AirlineID = ""
        
        self.AirlineDescription = ""
        
        self.AirlineType = ""
        
        self.category = Category
    }
    
    
    
    
    
    init(AirlineID: String,AirlineDescription: String,AirlineType: String,category: AirlineCategory){
        self.AirlineID = AirlineID
        self.AirlineDescription = AirlineDescription
        self.AirlineType = AirlineType
        self.category = category
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.AirlineID != nil{
            returnData += "\n Airlines Id : " + self.AirlineID!
        }
        
        if self.AirlineDescription != nil{
            returnData += "\n Airlines Description : " + self.AirlineDescription!
        }
        
        if self.AirlineType != nil{
            returnData += "\n Airlines Type : " + self.AirlineType!
        }
        
        if self.Category != nil{
            returnData += "\n Category :  " self.category!
        }
        
        return returnData
    }
    
    
    
    
    
    
    
    
    func registerUser(){
        
        print("Enter Airline Id : ")
        
        self.AirlineID = readLine()!
        
        print("Enter Airline Description : ")
        
        self.AirlineDescription = readLine()!
        
        print("Enter Airline Type : ")
        
        self.AirlineType = readLine()!
        
    }
    
    
}
