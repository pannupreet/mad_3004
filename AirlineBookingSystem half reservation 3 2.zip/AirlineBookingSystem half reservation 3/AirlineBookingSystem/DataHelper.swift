//
//  DataHelper.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    
    var AirlineList = [String : Airline]()
    
    
    
    init(){
        self.loadAirlineData()
        
    }
    
    
    
    func loadAirlineData(){
        
        AirlineList = [:]
        
        
        let AirCanada = Airline(AirlineID: "A100", AirlineDescription: "One of the best indian airline" , AirlineType : "International" , category: AirlineCategory.airlineID)
        
        AirlineList[AirCanada.AirlineID!] = AirCanada
        
        let Lufthansa = Airline(AirlineID: "B101", AirlineDescription: "First Canadian airline" , AirlineType: "International" ,category: AirlineCategory.airlineID)
        
        AirlineList[Lufthansa.AirlineID!] = Lufthansa
        
        let AirIndia = Airline(AirlineID: "C102", AirlineDescription: "Most preffeble airline" , AirlineType: "International" , category: AirlineCategory.airlineID )
        
        AirlineList[AirIndia.AirlineID!] = AirIndia
        
        let Westjet = Airline(AirlineID: "D103", AirlineDescription: "Common airline" , AirlineType: "International", category: AirlineCategory.airlineID )
        
        AirlineList[Westjet.AirlineID!] = Westjet
        
    }
    
    func displayAirline(){
        
        for (_, value) in self.AirlineList.sorted(by: { $0.key < $1.key} ){
            
            print(value.displayData())
            
        }
        
    }
    
}


