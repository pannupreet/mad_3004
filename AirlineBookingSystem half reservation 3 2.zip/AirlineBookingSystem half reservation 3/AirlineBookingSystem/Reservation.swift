//
//  Reservation.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Reservation{
    
    
    
    private var reservation_id : String?
    private var reservation_description: String?
    private var reservation_passenger_id: String?
    private var reservation_flight_id: String?
    private var reservation_seat_number: String?
    private var reservation_status : String?
    private var reservation_meal_type : String?
    
    
    
    
    
    var Reservation_id : String? {
        get{return self.reservation_id}
        set{self.reservation_id = newValue}
    }
    var Reservation_description : String?{
        get{return self.reservation_description}
        set{self.reservation_description = newValue}
    }
    
    var Reservation_passenger_id : String?{
        get{return self.reservation_passenger_id}
        set{self.reservation_passenger_id = newValue}
    }
    var Reservation_flight_id : String?{
        get{return self.reservation_flight_id}
        set{self.reservation_flight_id = newValue}
    }
    var Reservation_seat_number : String?{
        get{return self.reservation_seat_number}
        set{self.reservation_seat_number = newValue}
    }
    
    var Reservation_status : String?{
        get{return self.reservation_status}
        set{self.reservation_status = newValue}
    }
    var Reservation_meal_type : String?{
        get{return self.reservation_meal_type}
        set{self.reservation_meal_type = newValue}
    }
    
    
    
    
    
    
    
    
    
    init(){
        self.reservation_id = ""
        self.reservation_description = ""
        self.reservation_passenger_id = ""
        self.reservation_flight_id = ""
        
        self.reservation_seat_number = ""
        self.reservation_status = ""
        
        
    }
    
    
    
    init(reservation_id: String, reservation_description: String,
            reservation_passenger_id: String,reservation_flight_id: String,reservation_seat_number: String,reservation_status: String){
        
        
        
        self.reservation_id = reservation_id
        self.reservation_description = reservation_description
        self.reservation_passenger_id = reservation_passenger_id
        self.reservation_flight_id = reservation_flight_id
        
        self.reservation_seat_number = reservation_seat_number
        self.reservation_status = reservation_status
        
    }
    
    
    
    func displayData() -> String{
        
        var returnData = ""
        
        
        
        if self.reservation_id != nil{
            
            returnData += "Reservation ID : \(String(describing: self.reservation_id))"
            
        }
        
        if self.reservation_description != nil{
            
            returnData += "\n Airline Description : " + self.reservation_description!
            
        }
        if self.reservation_passenger_id != nil{
            
            returnData += "\n Airline Description : " + self.reservation_passenger_id!
            
        }
        if self.reservation_flight_id != nil{
            
            returnData += "\n Airline Description : " + self.reservation_flight_id!
            
        }
        
        if self.reservation_seat_number != nil{
            
            returnData += "\n Airline Description : " + self.reservation_seat_number!
            
        }
        if self.reservation_status != nil{
            
            returnData += "\n Airline Description : " + self.reservation_status!
            
        }
        
        
        
        return returnData
        
    }
    
    
    
    func registerUser(){
        
        print("Enter Airline Id : ")
        
        self.reservation_id = readLine()!
        
        print("Enter Airline Description : ")
        
        self.reservation_description = readLine()!
        
        print("Enter Airline Description : ")
        
        self.reservation_passenger_id = readLine()!
        
        print("Enter Airline Description : ")
        
        self.reservation_flight_id = readLine()!
        
        print("Enter Airline Description : ")
        
        self.reservation_seat_number = readLine()!
        
        print("Enter Airline Description : ")
        
        self.reservation_status = readLine()!
        
       
        
    }
    
}

