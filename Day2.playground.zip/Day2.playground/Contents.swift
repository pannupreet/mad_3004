//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)

var greet="""
Haalo Friends,
How are you doing!
Clidy weather...
Boring class
Funny Friends
"""

print(greet)

let mood="\u{1F496}"

print(mood)
if mood.isEmpty{
    print("No mood")
}else{
    greet += mood
}
greet += mood
print(greet)
var player=String()
player="Dhoni"
print(player)
for o in player{
    print(o)
}

//var initial : Character="j"
//player.append(initial)

player.append(" Go Go Go")
print(player)

print("Length of player : ",player.count)

print("Start Index of player :\(player[player.startIndex])")
//print("End Index of player :\(player[player.endIndex])")
print("last chracter of player \(player[player.index(before:player.endIndex)])")

print("some character : \(player[player.index(after:player.startIndex)])")
print("2nd characteer : \(player[player.index(player.startIndex,offsetBy : 1)])")
print("3rd characteer from end : \(player[player.index(player.endIndex,offsetBy : -4)])")

//var idx=player.index(player.endIndex,offsetBy: -5)
//print("\(player[idx])")

for index in greet.indices{
    print("\(greet[index])",terminator:"_")
}

for(index,value) in player.enumerated(){
   print("\n\nIndex :\(index) --- value : \(value)")
}


player.insert("!",at: player.endIndex)
player.insert(contentsOf:" win it..",at:player.endIndex)
print(player)
//var idx1=player.index(of:"G")
//print("idx1 : \(idx1)")

//print(player)

//var idxG=player.index(of: "G")// team.endIndex

//player.removeSubrange(player.startIndex..<idxG)

print(player.uppercased())
